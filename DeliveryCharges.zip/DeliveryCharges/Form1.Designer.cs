﻿namespace DeliveryCharges
{
    partial class DeliveryCharges
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            costButton = new Button();
            instLabel = new Label();
            inputZip = new TextBox();
            outputLabel = new Label();
            errorMsg = new Label();
            SuspendLayout();
            // 
            // costButton
            // 
            costButton.Location = new Point(112, 136);
            costButton.Name = "costButton";
            costButton.Size = new Size(125, 29);
            costButton.TabIndex = 0;
            costButton.Text = "Delivery Cost";
            costButton.UseVisualStyleBackColor = true;
            costButton.Click += Button1_Click;
            // 
            // instLabel
            // 
            instLabel.AutoSize = true;
            instLabel.Location = new Point(112, 55);
            instLabel.Name = "instLabel";
            instLabel.Size = new Size(122, 20);
            instLabel.TabIndex = 1;
            instLabel.Text = "Enter A Zip Code";
            // 
            // inputZip
            // 
            inputZip.Location = new Point(112, 94);
            inputZip.Name = "inputZip";
            inputZip.Size = new Size(125, 27);
            inputZip.TabIndex = 2;
            // 
            // outputLabel
            // 
            outputLabel.BorderStyle = BorderStyle.Fixed3D;
            outputLabel.Location = new Point(112, 185);
            outputLabel.Name = "outputLabel";
            outputLabel.Size = new Size(125, 25);
            outputLabel.TabIndex = 3;
            // 
            // errorMsg
            // 
            errorMsg.AutoSize = true;
            errorMsg.Location = new Point(32, 222);
            errorMsg.Name = "errorMsg";
            errorMsg.Size = new Size(291, 20);
            errorMsg.TabIndex = 4;
            errorMsg.Text = "Sorry - We do not delivery to that location.";
            errorMsg.Visible = false;
            // 
            // deliveryCharges
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(357, 291);
            Controls.Add(errorMsg);
            Controls.Add(outputLabel);
            Controls.Add(inputZip);
            Controls.Add(instLabel);
            Controls.Add(costButton);
            Name = "deliveryCharges";
            Text = "Delivery Charges";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button costButton;
        private Label instLabel;
        private TextBox inputZip;
        private Label outputLabel;
        private Label errorMsg;
    }
}
