namespace DeliveryCharges
{
    public partial class DeliveryCharges : Form
    {
        public DeliveryCharges()
        {
            InitializeComponent();
        }
        string[] zips = { "00000", "11111", "22222", "33333", "44444", 
            "55555", "66666", "77777", "88888", "99999"};
        string[] prices = {"$10.00", "$11.11", "$12.22", "$13.33", "$14.44", 
            "$15.55", "$16.66", "$17.77", "$18.88", "$19.99"};
        private void Button1_Click(object sender, EventArgs e)
        {
            int integer;
            int validValue = 10;
            for (integer = 0; integer < validValue; ++integer)
            {
                if (inputZip.Text == zips[integer])
                {
                    validValue = integer;
                    outputLabel.Text = prices[integer];
                    errorMsg.Visible = false;
                }
                else
                {
                    outputLabel.Text = "Error";
                    errorMsg.Visible = true;
                }
            }
        }
    }
}
